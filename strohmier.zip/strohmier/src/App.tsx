import { useState } from "react";
import NavBar from "./components/NavBar";
import Home from "./components/Home";
import Research from "./components/Research";
import Accolades from "./components/Accolades";
import Footer from "./components/Footer";
import "./App.css";
//Main function, use to change the page contain and the colors of the navbar
function App() {
  const [color, setColor] = useState("#88527F");
  const [title, setTitle] = useState("Hala Strohmier Berry - Home");
  const [page, setPage] = useState("home");

  return (
    <div>
      <NavBar
        color={color}
        title={title}
        page={page}
        setColor={setColor}
        setTitle={setTitle}
        setPage={setPage}
      />
      {page === "home" ? (
        <Home
          title={title}
          page={page}
          setColor={setColor}
          setTitle={setTitle}
          setPage={setPage}
        />
      ) : page === "research" ? (
        <Research />
      ) : page === "accolades" ? (
        <Accolades />
      ) : (
        //add 404 page
        404
      )}
      <Footer />
    </div>
  );
}

export default App;
