import "./Research.css";
import scholar from "./img/Google_Scholar_logo.svg.png";
//Contains all of the info for the accolades page
//
//Create more <li> entries to add more research
function Research() {
  return (
    <>
      <div className="publicationsContainer">
        <h2 id="publicationsHeader">List of Publications</h2>
        <a
          id="publications"
          href="https://scholar.google.com/citations?user=B0c7AikAAAAJ&hl=en"
        >
          My publication list can be found here
        </a>
        <img id="icon" src={scholar} alt="Google scholar" />
      </div>
      <div className="spacer"></div>
      <div className="researchContainer">
        <h3 id="researchHeader">List of current research</h3>
        <p className="subtitle">Summary: 14</p>
        <ol
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            paddingRight: "3vw",
          }}
        >
          <div className="leftRContainer">
            <li>
              <h1 className="researchName">
                GenCyber and CCIA Webpages for USCA
              </h1>
              <p>
                I. Ervin, A. Bhosle, O. Naik<br></br>University of South
                Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">Machine Learning Project</h1>
              <p>
                G. Calloway, T. Green<br></br>University of South Carolina-Aiken
                2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">SRNS Project</h1>
              <p>
                S. Canepa<br></br>Savannah River Nuclear Solutions 2023
              </p>
            </li>
            <li>
              <h1 className="researchName">Blog for Dr. Warren</h1>
              <p>
                A. Walters, S. Rostron, O. Chew<br></br>University of South
                Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">ChatGPT Research Paper</h1>
              <p>
                Y. Dasri, D. Murzello<br></br>University of South Carolina-Aiken
                2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">Mobile Cybersecurity Game</h1>
              <p>
                J. Hall, J. Walker<br></br>University of South Carolina-Aiken
                2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">Cybersecurity Awareness Program</h1>
              <p>
                C.Clark, M. Heinbaugh, D. Jones, C. Peace<br></br>University of
                South Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">SRTE-Project with SRS</h1>
              <p>
                C. Stoles, I. Hutto<br></br>Savannah River Site 2023.
              </p>
            </li>
          </div>
          <div className="rightRContainer">
            <li>
              <h1 className="researchName">SOC Project</h1>
              <p>
                C. Clark, A. Kahn, M. Vohra<br></br>University of South
                Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">ICS SCADA Project</h1>
              <p>
                C. Clark, B. Kram, A. Londhe, R. Pawar<br></br>University of
                South Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">Machine Learning/AI Research</h1>
              <p>
                V. Langner, F. Mohamed, E. Wood<br></br>University of South
                Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">IoT/5G Vulnerability Project</h1>
              <p>
                J. Lowe, A. Rodriguez, M. Trammell<br></br>University of South
                Carolina-Aiken 2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">SRNS Scheduling Project</h1>
              <p>
                A. Kepler, S. Lyon<br></br>Savannah River Nuclear Solutions 2023
                2023.
              </p>
            </li>
            <li>
              <h1 className="researchName">Android App</h1>
              <p>
                R. Li, S. Mitra<br></br>University of South Carolina-Aiken 2023.
              </p>
            </li>
          </div>
        </ol>
      </div>
    </>
    //count for summary total
  );
}

export default Research;
