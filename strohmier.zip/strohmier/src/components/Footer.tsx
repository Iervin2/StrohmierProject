import "./Footer.css";

function Footer() {
  return (
    <>
      <div className="spacer"></div>
      <div className="footerContainer">
        <div className="email">
          Email<br></br>
          <a id="emailLink" href="hala.strohmier@usca.edu">
            hala.strohmier@usca.edu
          </a>
        </div>
        <div className="scholar">
          Google Scholar<br></br>
          <a
            id="scholarLink"
            href="https://scholar.google.com/citations?user=B0c7AikAAAAJ&hl=en"
          >
            https://scholar.google.com/citations?user=B0c7AikAAAAJ&hl=en
          </a>
        </div>
        <div className="linkedin">
          LinkedIn<br></br>
          <a id="linkedinLink" href="https://www.linkedin.com/in/strohmierhala">
            https://www.linkedin.com/in/strohmierhala
          </a>
        </div>
      </div>
    </>
  );
}

export default Footer;
