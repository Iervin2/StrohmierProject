import "./NavBar.css";

interface Props {
  color: string;
  title: string;
  page: string;
  setColor: (item: string) => void;
  setTitle: (item: string) => void;
  setPage: (item: string) => void;
}
//Contains all the content for the navbar at the top of the page
function NavBar({ color, setColor, setTitle, setPage }: Props) {
  return (
    <>
      <div className="nav">
        <title>Hala Strohmier Berry - Home</title>
        <div className="titleContainer">
          <div
            className="circle"
            style={{
              border: "none",
              backgroundColor: color,
              borderRadius: 50,
              height: 25,
              width: 25,
            }}
          ></div>
          <button
            className="links"
            id="h_link"
            onClick={() => {
              setColor("#88527F");
              setTitle("Hala Strohmier Berry - Home");
              setPage("home");
            }}
          >
            Hala Strohmier Berry
          </button>
          <h1 className="job">Cyber-Security Analyst</h1>
        </div>
        <div className="linksContainer">
          <button
            className="links"
            id="r_link"
            onClick={() => {
              setColor("#F25F5C");
              setTitle("Hala Strohmier Berry - Research");
              setPage("research");
            }}
          >
            Research
          </button>
          <button
            className="links"
            id="a_link"
            onClick={() => {
              setColor("#80D8DA");
              setTitle("Hala Strohmier Berry - Accolades");
              setPage("accolades");
            }}
          >
            Accolades
          </button>
        </div>
      </div>
    </>
  );
}

export default NavBar;
