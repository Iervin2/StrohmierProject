import "./Accolades.css";
//Contains all of the info for the accolades page
//
//Create subLeft and subRight divs to add more entries
function Accolades() {
  return (
    <>
      <div className="headContainer">
        <h1 id="accoladesHeader">Accolades</h1>
        <p id="accSubtitle">
          Since I started my studies in Information System, I have been devoting
          time to doing outreach.
        </p>
      </div>
      <div className="spacer"></div>
      <div id="eduContainer">
        <div className="leftContainer">
          <h1 className="accHeader">Education</h1>
        </div>
        <div className="rightContainer">
          <div className="entryContainer">
            <h2 className="dateHeader">1994</h2>
            <div className="entry">
              <h1 className="entryName">
                Bachlor's in Business Administartion and Accounting
              </h1>
              <p className="entryInfo">Cario University, Giza, Egypt</p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader">2002</h2>
            <div className="entry">
              <h1 className="entryName">M.S. in Information Systems</h1>
              <p className="entryInfo">
                The George Washington University, Washington D.C.
              </p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader">2019</h2>
            <div className="entry">
              <h1 className="entryName">
                Ph.D. in Engineering, Engineering Management
              </h1>
              <p className="entryInfo">
                The George Washington University, Washington D.C.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="spacer"></div>
      <div id="awardsContainer">
        <div className="leftContainer">
          <h1 className="accHeader">Special Honors and Awards</h1>
        </div>
        <div className="rightContainer">
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">Valedictorian</h1>
              <p className="entryInfo"></p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">Auditor of the year</h1>
              <p className="entryInfo"></p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">
                Technical Project Manager of the year
              </h1>
              <p className="entryInfo"></p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">Management of Excellence Awards</h1>
              <p className="entryInfo"></p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">
                Top Diversity Owned Woman Owned Business
              </h1>
              <p className="entryInfo"></p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">Top Small Business Leader Awards</h1>
              <p className="entryInfo"></p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName">Top Small Business Leader Awards</h1>
              <p className="entryInfo"></p>
            </div>
          </div>
        </div>
      </div>
      <div className="spacer"></div>
      <div id="guestContainer">
        <div className="leftContainer">
          <h1 className="accHeader">Guess speaker at</h1>
        </div>
        <div className="rightContainer">
          <div className="entryContainer">
            <h2 className="dateHeader">2022</h2>
            <div className="entry">
              <h1 className="entryName">
                IEEE International Conference on Computer and Application
              </h1>
              <p className="entryInfo">
                Institute of Electrical and Electronics Engineers
              </p>
            </div>
          </div>
          <div className="entryContainer">
            <h2 className="dateHeader">2023</h2>
            <div className="entry">
              <h1 className="entryName">Securing the Future</h1>
              <p className="entryInfo">
                Exploring Innovations, Collaboration, and Education in
                Cybersecurity
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="spacer"></div>
      <div id="invitedContainer">
        <div className="leftContainer">
          <h1 className="accHeader">Invited speaker at</h1>
        </div>
        <div className="rightContainer">
          <div className="entryContainer">
            <h2 className="dateHeader"></h2>
            <div className="entry">
              <h1 className="entryName"></h1>
              <p className="entryInfo"></p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Accolades;
