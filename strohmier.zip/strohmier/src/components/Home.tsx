import headshot from "./img/strohmier-headshot.jpg";
import "./Home.css";
interface Props {
  title: string;
  page: string;
  setColor: (item: string) => void;
  setTitle: (item: string) => void;
  setPage: (item: string) => void;
}
//Contains all of the displayed content for the home page
function Home({ setColor, setTitle, setPage }: Props) {
  return (
    <>
      <div className="contentContainer">
        <div className="headshotContainer">
          <img src={headshot} alt="Hala headshot"></img>
        </div>
        <div className="infoContainer">
          <div className="bio">
            <h1 className="name">Hala Strohmier Berry</h1>
            <h2 className="bio">A Bit About Me</h2>
            <p className="bio_info">
              I am an Assistant Professor of Computer Science/Cybersecurity and
              the director of the USC Aiken Center for Cyber Initiatives and
              Awareness &#40;CCIA&#41; at College of Sciences and Engineering,
              the University of South Carolina Aiken. I received my Doctor of
              Engineering and Master of Science in Information Systems
              Technology from George Washington University, Washington DC. Prior
              to joining the University of South Carolina Aiken, I was a
              Computer Science faculty at the University of North Carolina
              Wilmington from 2020 to 2022, before that I was the founder and
              managing member of Strohmier Consulting LLC, an award-winning
              Engineering and Information Technology company headquarters in
              Ashburn, Virginia and operating office in Charleston, South
              Carolina with operations in 9 states, focused on Cybersecurity,
              Governance, and Risk Management, during its tenure of 14 plus
              years, I received numerous awards including top woman-owned
              business, top diversity owned business and top CEO. I served both
              Commercial and Government clients. Prior to that, I worked in the
              Telecom industry, and started my career in the Assurance and
              Advisory group at Deloitte. My research interests include the
              areas of Cybersecurity, Cyber Operations, and Digital Forensics.
            </p>
          </div>
          <div className="navButtons">
            <button
              id="r_button"
              onClick={() => {
                setColor("#F25F5C");
                setTitle("Hala Strohmier Berry - Research");
                setPage("research");
              }}
            >
              Research
            </button>
            <button
              id="a_button"
              onClick={() => {
                setColor("#80D8DA");
                setTitle("Hala Strohmier Berry - Accolades");
                setPage("accolades");
              }}
            >
              Accolades
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;
